# AKSwiftSlideMenu

Slide Menu (Drawer) in Swift 3

Why to use a library everytime?

Let's create our own Slide Menu in Swift 3.

<a href='https://pledgie.com/campaigns/31006'><img alt='Click here to lend your support to: Help by code and make a donation at pledgie.com !' src='https://pledgie.com/campaigns/31006.png?skin_name=chrome' border='0' ></a>

![Slide Menu Example Image](https://cloud.githubusercontent.com/assets/6905345/10064748/8b39581e-6299-11e5-8829-d003e4069f30.png)

I have written an article about this on my website http://ashishkakkad.com/2015/09/create-your-own-slider-menu-drawer-in-swift-2-ios-9/

Happy Coding :)
